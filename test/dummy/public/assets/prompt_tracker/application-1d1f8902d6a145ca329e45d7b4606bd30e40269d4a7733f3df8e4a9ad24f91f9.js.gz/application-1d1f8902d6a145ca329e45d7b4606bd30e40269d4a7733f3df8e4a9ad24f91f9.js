
// If the engine UI uses Bootstrap:
import "@hotwired/turbo-rails"
// Import Stimulus controllers
import "prompt_tracker/controllers"

// Import Chart.js UMD bundle (automatically assigns to window.Chart)
import "chart.js";
